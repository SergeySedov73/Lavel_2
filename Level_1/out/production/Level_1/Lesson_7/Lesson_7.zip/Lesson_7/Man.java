package Lesson_7;

public class Man {
}
